package Test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contactPackage.Contact;
import contactPackage.ContactService;

class ContactServiceTest {

	private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
    	
        String id = "1";
        String firstName = "John";
        String lastName = "Doe";
        String phoneNumber = "1234567890";
        String address = "123 Main St";

        contactService.addContact(id, firstName, lastName, phoneNumber, address);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(id, "Jane", "Smith", "9876543210", "456 Elm St");
        });
    }

    @Test
    public void testDeleteContact() {
        String id = "1";
        String firstName = "John";
        String lastName = "Doe";
        String phoneNumber = "1234567890";
        String address = "123 Main St";
        contactService.addContact(id, firstName, lastName, phoneNumber, address);

        contactService.deleteContact(id);

        Contact contact = contactService.getContact(id);
        Assertions.assertNull(contact);
    }

    @Test
    public void testUpdateContact() {
        String id = "1";
        String firstName = "John";
        String lastName = "Doe";
        String phoneNumber = "1234567890";
        String address = "123 Main St";
        contactService.addContact(id, firstName, lastName, phoneNumber, address);

        String updatedFirstName = "Jane";
        String updatedLastName = "Smith";
        String updatedPhoneNumber = "9876543210";
        String updatedAddress = "456 Elm St";
        contactService.updateContact(id, updatedFirstName, updatedLastName, updatedPhoneNumber, updatedAddress);
        
        Contact contact = contactService.getContact(id);
        
        Assertions.assertNotNull(contact);
        Assertions.assertEquals(id, contact.getId());
        Assertions.assertEquals(updatedFirstName, contact.getFirstName());
        Assertions.assertEquals(updatedLastName, contact.getLastName());
        Assertions.assertEquals(updatedPhoneNumber, contact.getPhoneNumber());
        Assertions.assertEquals(updatedAddress, contact.getAddress());
    }
    
    @Test
    public void testUpdateContactWrongId() {
    	
    	String id = "1";
        String firstName = "John";
        String lastName = "Doe";
        String phoneNumber = "1234567890";
        String address = "123 Main St";
        contactService.addContact(id, firstName, lastName, phoneNumber, address);

        String updatedFirstName = "Jane";
        String updatedLastName = "Smith";
        String updatedPhoneNumber = "9876543210";
        String updatedAddress = "456 Elm St";
    	
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	contactService.updateContact("-1", updatedFirstName, updatedLastName, updatedPhoneNumber, updatedAddress);
        });
    }
    
    @Test
    public void testGetContact() {
        String id = "1";
        String firstName = "John";
        String lastName = "Doe";
        String phoneNumber = "1234567890";
        String address = "123 Main St";
        contactService.addContact(id, firstName, lastName, phoneNumber, address);

        Contact contact = contactService.getContact(id);

        Assertions.assertNotNull(contact);
        Assertions.assertEquals(id, contact.getId());
        Assertions.assertEquals(firstName, contact.getFirstName());
        Assertions.assertEquals(lastName, contact.getLastName());
        Assertions.assertEquals(phoneNumber, contact.getPhoneNumber());
        Assertions.assertEquals(address, contact.getAddress());
    }

}
