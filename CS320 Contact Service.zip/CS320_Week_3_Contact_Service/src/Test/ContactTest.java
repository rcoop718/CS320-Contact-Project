package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactPackage.Contact;

class ContactTest {
	
	@Test
	void testContact() {
		Contact contact = new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
		assertTrue(contact.getId().equals("12345"));
		assertTrue(contact.getFirstName().equals("Ryan"));
		assertTrue(contact.getLastName().equals("Cooper"));
		assertTrue(contact.getPhoneNumber().equals("0123456789"));
		assertTrue(contact.getAddress().equals("123 Sesame Street"));
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345", "Ryan Cooper", "Cooper", "0123456789", "123 Sesame Street");
			});		}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345", "Ryan", "Ryan Cooper", "0123456789", "123 Sesame Street");
			});		}
	
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345678910", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
			});		}
	
	@Test
	void testContactPhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345", "Ryan", "Cooper", "12345678910", "123 Sesame Street");
			});		}
	
	@Test
	void testContactPhoneNumberTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345", "Ryan", "Cooper", "012345678", "123 Sesame Street");
			});		}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street plus some words");
			});		}
	
	
	@Test
	void testContactSetFirstName() {
		Contact contact = new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
		
		String newFirstName = "John";
		
		contact.setFirstName(newFirstName);
		
		assertEquals(newFirstName, contact.getFirstName());
				
	}
	
	@Test
	void testContactSetLastName() {
		Contact contact = new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
		
		String newLastName = "Doe";
		
		contact.setLastName(newLastName);
		
		assertEquals(newLastName, contact.getLastName());
	}
	
	@Test
	void testContactSetPhoneNumber() {
		Contact contact = new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
		
		String newPhoneNumber = "1112223333";
		
		contact.setPhoneNumber(newPhoneNumber);
		
		assertEquals(newPhoneNumber, contact.getPhoneNumber());
	}
	
	@Test
	void testContactSetAddress() {
		Contact contact = new Contact( "12345", "Ryan", "Cooper", "0123456789", "123 Sesame Street");
		
		String newAddress = "798 Made-Up Street";
		
		contact.setAddress(newAddress);
		
		assertEquals(newAddress, contact.getAddress());
	}
}
