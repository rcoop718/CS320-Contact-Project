package contactPackage;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	private Map<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<>();
    }

    public void addContact(String id, String firstName, String lastName, String phoneNumber, String address) {
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact with ID " + id + " already exists.");
        }
        Contact contact = new Contact(id, firstName, lastName, phoneNumber, address);
        contacts.put(id, contact);
    }

    public void deleteContact(String id) {
        contacts.remove(id);
    }

    public void updateContact(String id, String firstName, String lastName, String phoneNumber, String address) {
        if (!contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact with ID " + id + " does not exist.");
        }
        Contact contact = contacts.get(id);
        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        if (phoneNumber != null) {
            contact.setPhoneNumber(phoneNumber);
        }
        if (address != null) {
            contact.setAddress(address);
        }
    }

    public Contact getContact(String id) {
        return contacts.get(id);
    }

    
}
